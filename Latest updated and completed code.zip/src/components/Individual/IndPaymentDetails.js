import React, { Component } from 'react'
import { Stepper } from 'react-form-stepper'
import '../../App.css'

class IndPaymentDetails extends Component {
  back = e => {
    e.preventDefault()
    this.props.prevStep()
  }

  continue = e => {
    e.preventDefault()
    this.props.nextStep()
  }
  // constructor (props) {
  //   super(props)
  //   this.state = {
  //     friends: [],
  //     name: '',
  //     id: '',
  //     notes: ''
  //   }

  //   this.submit = this.submit.bind(this)
  //   // this.update = this.update.bind(this)
  //   // this.delete = this.delete.bind(this)
  //   this.handleChange = this.handleChange.bind(this)
  // }

  render () {
    const { values } = this.props

    // const {
    //   //  profession,
    //   cashorcheque,
    //   sourceoffunds,
    //   purposeoftransaction,
    //   beneficiaryname,
    //   bankaccountdetails,
    //   expectedannualactivity,
    //   annualvalue,
    //   numberoftransactions,

    //   // email,
    //   // phone,
    //   handleChange,
    //   //   validateFirstName,
    //   //   validateLastName,
    //   //   isErrorFirstName,
    //   //   isErrorLastName,
    //   //   errorMessageFirstName,
    //   //   errorMessageLastName
    //   validateprofession,
    //   isErrorProfession,
    //   isErrorbeneficiaryname,
    //   errorMessagebeneficiaryname,
    //   isErrorexpectedannualactivity,
    //   errorMessageexpectedannualactivity,

    //   errorMessageProfession,
    //   validateCashorcheque,
    //   validateSourceofFunds
    // } = this.props

    return (
      <div className='form'>
        <form>
          <Stepper
            steps={[
              { label: 'Personal details' },
              { label: 'Address details' },
              { label: 'Payment Details' },
              { label: 'Summary' }
            ]}
            activeStep={2}
            styleConfig={{
              activeBgColor: '#2b7cff',
              activeTextColor: '#fff',
              inactiveBgColor: '#fff',
              inactiveTextColor: '#2b7cff',
              completedBgColor: '#fff',
              completedTextColor: '#2b7cff',
              size: '3em'
            }}
            className={'stepper'}
            stepClassName={'stepper__step'}
          />

          <div className='form-group'>
            <div className='form-group__element'>
              <label htmlFor='Profession' className='form-group__label'>
                Profession
              </label>
              <input
                type='text'
                //value={profession}
                // defaultValue={profession}
                name='Profession'
                placeholder='Profession'
                onChange={this.props.handleChange('Profession')}
                defaultValue={values.Profession}
                // id='profession'
                //value={this.props.profession}
                //  onChange={this.props.onChange}
                className='form-group__input'
              />
              {/* <p className='error'>
                {isErrorProfession && errorMessageProfession}
              </p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='methodofpayment' className='form-group__label'>
                Method of Payment
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('methodofpayment')}
                defaultValue={values.methodofpayment}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='sourceoffunds' className='form-group__label'>
                Source of Funds
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('sourceoffunds')}
                defaultValue={values.sourceoffunds}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='beneficiaryName' className='form-group__label'>
                Beneficiary Name
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('beneficiaryName')}
                defaultValue={values.beneficiaryName}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='expectedAnnualActivity'
                className='form-group__label'
              >
                Expected Annual Activity
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('expectedAnnualActivity')}
                defaultValue={values.expectedAnnualActivity}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='phoneNumber' className='form-group__label'>
                Phone Number
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('phoneNumber')}
                defaultValue={values.phoneNumber}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='faxNumber' className='form-group__label'>
                Fax Number
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('faxNumber')}
                defaultValue={values.faxNumber}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='typeOfBusiness' className='form-group__label'>
                Type Of Business
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('typeOfBusiness')}
                defaultValue={values.typeOfBusiness}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='namesOfUBO' className='form-group__label'>
                Names Of UBO
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('namesOfUBO')}
                defaultValue={values.namesOfUBO}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='iddetailsofUB' className='form-group__label'>
                Id Details of UB
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('iddetailsofUB')}
                defaultValue={values.iddetailsofUB}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='idTypeOfUBO' className='form-group__label'>
                IdTypeOfUBO
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('idTypeOfUBO')}
                defaultValue={values.idTypeOfUBO}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='idNumbersOfUBO' className='form-group__label'>
                idNumbersOfUBO
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('idNumbersOfUBO')}
                defaultValue={values.idNumbersOfUBO}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='authPersonName' className='form-group__label'>
                authPersonName
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('authPersonName')}
                defaultValue={values.authPersonName}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='idTypeAuthPerson' className='form-group__label'>
                id Type Auth Person
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('idTypeAuthPerson')}
                defaultValue={values.idTypeAuthPerson}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>

            <div className='form-group__element'>
              <label htmlFor='idNumberAuthPerson' className='form-group__label'>
                idNumberAuthPerson
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('idNumberAuthPerson')}
                defaultValue={values.idNumberAuthPerson}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
          </div>

          <div style={{ textAlign: 'center' }}>
            <button
              className='buttons__button buttons__button--back'
              onClick={this.back}
            >
              Back
            </button>
            <button
              className='buttons__button buttons__button--next'
              onClick={this.continue}
              // onClick={e => this.submit(e)}
            >
              Next
            </button>
          </div>
        </form>
      </div>
    )
  }
}

export default IndPaymentDetails
