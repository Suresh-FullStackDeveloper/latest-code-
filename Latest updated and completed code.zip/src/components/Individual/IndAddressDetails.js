import React, { Component } from 'react'
import { Stepper } from 'react-form-stepper'
import '../../App.css'
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core'

class IndAddressDetails extends Component {
  back = e => {
    e.preventDefault()
    this.props.prevStep()
  }

  continue = e => {
    e.preventDefault()
    // const isEmiratesId = this.props.validateEmiratesId()
    // const isPassport = this.props.validatePassport()
    // if (isEmiratesId && isPassport) {
    this.props.nextStep()
    // }
  }

  render () {
    const { values } = this.props

    // const {
    //   //  emiratesid,
    //   passport,
    //   gccnationalid,
    //   idnumber,
    //   idplaceofissue,
    //   idissuedate,
    //   idexpirydate,

    //   // email,
    //   // phone,
    //   handleChange,
    //   validateEmiratesId,
    //   validatePassport,
    //   isErrorEmiratesId,
    //   isErrorPassport,
    //   errorMessageEmiratesId,
    //   errorMessagePassport
    // } = this.props
    const theme = createMuiTheme({
      palette: {
        primary: {
          main: '#003487'
        },
        secondary: {
          main: '#003487'
        }
      },
      overrides: {
        MuiPaper: {
          elevation2: {
            boxShadow: 'none'
          }
        },
        MuiInput: {
          underline: {
            '&:before': {
              borderBottom: 'none'
            },
            '&:after': {
              borderBottom: 'none'
            },
            '&:hover': {
              '&:not(.Mui-disabled)': {
                '&:before': {
                  borderBottom: 'none'
                }
              }
            }
          }
        },
        MuiTableRow: {
          root: {
            '&:nth-child(even)': {
              backgroundColor: '#ebebeb'
            }
          }
        },
        MuiTypography: {
          h6: {
            fontSize: '1rem',
            color: '#011b64'
          }
        },
        MuiToolbar: {
          root: {
            borderBottom: '1px solid grey',
            backgroundColor: '#fafafa'
          },
          gutters: {
            paddingLeft: '3px'
          }
        }
      }
    })

    return (
      <div className='form'>
        <form>
          <Stepper
            steps={[
              { label: 'Personal details' },
              { label: 'Address details' },
              { label: 'Payment Details' },
              { label: 'Summary' }
            ]}
            activeStep={1}
            styleConfig={{
              activeBgColor: '#2b7cff',
              activeTextColor: '#fff',
              inactiveBgColor: '#fff',
              inactiveTextColor: '#2b7cff',
              completedBgColor: '#fff',
              completedTextColor: '#2b7cff',
              size: '3em'
            }}
            className={'stepper'}
            stepClassName={'stepper__step'}
          />

          <div className='form-group'>
            <div className='form-group__element'>
              <label htmlFor='emirates id' className='form-group__label'>
                Emirates Id
              </label>
              <input
                type='text'
                name='emirates id'
                id='emiratesIdNumber'
                value={this.props.emiratesIdNumber}
                placeholder='Emirates Id'
                onChange={this.props.handleChange('emiratesIdNumber')}
                defaultValue={values.emiratesIdNumber}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='expiryDate' className='form-group__label'>
                Expiry Date
              </label>
              <input
                type='text'
                name='expiryDate'
                id='expiryDate'
                value={this.props.expiryDate}
                placeholder='expiryDate'
                onChange={this.props.handleChange('expiryDate')}
                defaultValue={values.expiryDate}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='country' className='form-group__label'>
                Country
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('country')}
                defaultValue={values.country}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='state' className='form-group__label'>
                State
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('state')}
                defaultValue={values.state}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='address1' className='form-group__label'>
                Address1
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('address1')}
                defaultValue={values.address1}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='address2' className='form-group__label'>
                Address2
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('address2')}
                defaultValue={values.address2}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='idType' className='form-group__label'>
                Id Type
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('idType')}
                defaultValue={values.idType}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='ResidentialStatus' className='form-group__label'>
                Residential Status
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('ResidentialStatus')}
                defaultValue={values.ResidentialStatus}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='temaddress' className='form-group__label'>
                Temporary Address
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('temaddress')}
                defaultValue={values.temaddress}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='compermanent' className='form-group__label'>
                Comp Address
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('compermanent')}
                defaultValue={values.compermanent}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>

            <div className='form-group__element'>
              <label htmlFor='email' className='form-group__label'>
                Email
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('email')}
                defaultValue={values.email}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>

            <div className='form-group__element'>
              <label htmlFor='idplaceofIssue' className='form-group__label'>
                Id Place Of Issue
              </label>
              <input
                type='text'
                onChange={this.props.handleChange('idplaceofIssue')}
                defaultValue={values.idplaceofIssue}
                className='form-group__input'
              />
              {/* <p className='error'>{isErrorFirstName && errorMessageFirstName}</p> */}
            </div>
          </div>

          <div className='table'>
            <MuiThemeProvider theme={theme}></MuiThemeProvider>
          </div>

          <div className='buttons'>
            <button
              className='buttons__button buttons__button--back'
              onClick={this.back}
            >
              Back
            </button>
            <button
              className='buttons__button buttons__button--next'
              onClick={this.continue}
            >
              Next
            </button>
          </div>
        </form>
      </div>
    )
  }
}

export default IndAddressDetails
