import React, { Component } from 'react'

// import PersonalDetails from './PersonalDetails'
// import CourseDetails from './CourseDetails'
// import Summary from './Summary'

import IndPersonalDetails from './IndPersonalDetails'
import IndAddressDetails from './IndAddressDetails'
import IndPaymentDetails from './IndPaymentDetails'
import IndSummary from './IndSummary'
//Sample data

//const levelsData = ['Beginner', 'Intermediate', 'Advanced']

class Individual extends Component {
  state = {
    step: 0,
    firstname: '',
    emiratesIdNumber: '',
    Profession: '',
    middleName: '',
    lastName: ''

    // lastname: '',
    // email: '',
    // phone: '',
    // courses: [],
    // level: '',
    // isErrorFirstName: true,
    // isErrorLastName: true,
    // errorMessageFirstName: '',
    // errorMessageLastName: ''
  }

  nextStep = () => {
    const { step } = this.state
    this.setState({
      step: step + 1
    })
  }

  prevStep = () => {
    const { step } = this.state
    this.setState({
      step: step - 1
    })
  }

  handleChange = input => e => {
    this.setState({
      [input]: e.target.value
    })

    // if (input === 'firstname') {
    //   if (this.state.firstname.length >= 1) {
    //     this.setState({
    //       isErrorFirstName: false
    //     })
    //   }
    // } else if (input === 'lastname') {
    //   if (this.state.lastname.length >= 1) {
    //     this.setState({
    //       isErrorLastName: false
    //     })
    //   }
    // }
  }

  // validateFirstName = () => {
  //   if (this.state.firstname.length < 2) {
  //     this.setState({
  //       isErrorFirstName: true,
  //       errorMessageFirstName: 'Type your first name (at least 2 characters)'
  //     })
  //     return false
  //   }
  //   return true
  // }

  // validateLastName = () => {
  //   if (this.state.lastname.length < 2) {
  //     this.setState({
  //       isErrorLastName: true,
  //       errorMessageLastName: 'Type your last name (at least 2 characters)'
  //     })
  //     return false
  //   }
  //   return true
  // }

  submitData = e => {
    e.preventDefault()
    alert('Data sent')
  }

  render () {
    const { step } = this.state
    const {
      firstName,
      emiratesIdNumber,
      Profession,
      middleName,
      lastName,
      placeOfBirth,
      bussinessType,
      sectorType,
      nationality,

      expiryDate,
      country,
      state,
      address1,
      address2,
      idType,
      ResidentialStatus,
      temaddress,
      compermanent,
      email,
      idplaceofIssue,

      //payment details

      methodofpayment,
      sourceoffunds,
      beneficiaryName,
      expectedAnnualActivity,
      phoneNumber,
      faxNumber,
      typeOfBusiness,
      namesOfUBO,
      iddetailsofUB,
      idTypeOfUBO,
      idNumbersOfUBO,
      authPersonName,
      idTypeAuthPerson,
      idNumberAuthPerson
    } = this.state
    const values = {
      firstName,
      emiratesIdNumber,
      Profession,
      middleName,
      lastName,
      placeOfBirth,
      bussinessType,
      sectorType,
      nationality,

      expiryDate,
      country,
      state,
      address1,
      address2,
      idType,
      ResidentialStatus,
      temaddress,
      compermanent,
      email,
      idplaceofIssue,

      //paymentdetails
      methodofpayment,
      sourceoffunds,
      beneficiaryName,
      expectedAnnualActivity,
      phoneNumber,
      faxNumber,
      typeOfBusiness,
      namesOfUBO,
      iddetailsofUB,
      idTypeOfUBO,
      idNumbersOfUBO,
      authPersonName,
      idTypeAuthPerson,
      idNumberAuthPerson
    }

    switch (step) {
      case 0:
        return (
          <IndPersonalDetails
            nextStep={this.nextStep}
            handleChange={this.handleChange}
            values={values}
          />
        )
      case 1:
        return (
          <IndAddressDetails
            nextStep={this.nextStep}
            prevStep={this.prevStep}
            handleChange={this.handleChange}
            values={values}
          />
        )
      case 2:
        return (
          <IndPaymentDetails
            nextStep={this.nextStep}
            prevStep={this.prevStep}
            handleChange={this.handleChange}
            values={values}
          />
        )
      case 3:
        return (
          <IndSummary
            nextStep={this.nextStep}
            prevStep={this.prevStep}
            values={values}
            submitData={this.submitData}
          />
        )
      default:
        return null
    }
  }
}

export default Individual
